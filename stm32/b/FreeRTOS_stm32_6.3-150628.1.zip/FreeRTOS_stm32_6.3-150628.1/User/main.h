
#ifndef __MAIN_H_
#define __MAIN_H_

#ifdef __MAIN_C_
#define __MAIN_EXT_
#else
#define __MAIN_EXT_ extern
#endif


__MAIN_EXT_ u8 MENULangType;


#endif


