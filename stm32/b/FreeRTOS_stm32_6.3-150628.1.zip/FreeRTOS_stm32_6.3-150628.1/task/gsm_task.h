
#ifndef __GSM_TASK_H_
#define __GSM_TASK_H_

#ifdef __GSM_TASK_C_
#define __GSM_TASK_EXT_
#else
#define __GSM_TASK_EXT_
#endif

#include "all.h"

void gsm_task(void *pdata);



#endif

