
#define __BACK_TASK_C_

#include "all.h"



/* ϵͳ1S ��̨����ʱ�� */
void __back_1s_handle(void)
{
	/* 7185 ��ʼ����δ�ɹ� */
	
}

void back_task(void *pdata)
{
	u8 ret;
	u32 msg;
	struct msg_head_list *p;

	printp("start back_task \r\n");
	
	p = msg_init_group();
	msg_set_group(p, MSG_GOURP_TIME);		//����������Ϣ

	for( ; ; )
	{
		ret = msg_get(p, &msg, 1000);

		if(ret != 0)
			continue;

		switch(msg){
			case IS_MSG(MSG_GOURP_TIME, MSG_TIME_1S):
				__back_1s_handle();
				break;
		}
	}
}

