#define __SYS_UART_C_

#include "all.h"

/************************************************************************

	����1��ʼ��
	
**************************************************************************/
void sys_uart1_init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	USART_InitTypeDef USART_InitStruct;
 	NVIC_InitTypeDef NVIC_InitStructure; 


	/* ����ʱ�� */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_USART1,ENABLE);

	/* ���ùܽ� */
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;

	GPIO_Init(GPIOA, &GPIO_InitStruct);

	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;
	
	GPIO_Init(GPIOA, &GPIO_InitStruct);

	
	/* ���üĴ��� */
	USART_InitStruct.USART_BaudRate = 115200;
	USART_InitStruct.USART_StopBits = USART_StopBits_1;
	USART_InitStruct.USART_WordLength = USART_WordLength_8b;
	USART_InitStruct.USART_Parity = USART_Parity_No;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStruct.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	
	USART_Init(USART1, &USART_InitStruct);
	USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);//ʹ�ܽ����ж�
	USART_Cmd(USART1, ENABLE);//ʹ�ܴ���1 

	/* �ж����� */
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn; 	//ͨ������Ϊ����1�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;   //�ж�ռ�ȵȼ�0
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;		  //�ж���Ӧ���ȼ�0
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			  //���ж�
	NVIC_Init(&NVIC_InitStructure);							  //��ʼ��
}


void sys_uart2_init(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;	
	// ����GPIO��ʼ���ṹ�� GPIO_InitStructure 
	GPIO_InitTypeDef GPIO_InitStructure;	
	// ����USART��ʼ���ṹ�� USART_InitStructure 
	USART_InitTypeDef USART_InitStructure;
	

	// ����USART2��Tx�ţ�PA.2��Ϊ�ڶ������������ģʽ
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA , &GPIO_InitStructure);
	
	// ����USART2��Rx�ţ�PA.3��Ϊ���������
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA , &GPIO_InitStructure); 
	
	// �� USART2 ʱ�� 
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2 , ENABLE); 	
	
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No ;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART2 , &USART_InitStructure);
	
	// ʹ��USART2�����ж�
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
	// ʹ��USART2
	USART_Cmd(USART2 , ENABLE);
	// Enable the USART2 Interrupt
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

}


void sys_uart1_sendchar(uint8_t data)
{
	/* Loop until the end of transmission */
	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);	
	USART_SendData(USART1,data);
}


void my_send_str(u8 *str)
{
	while((*str) != '\0')
	{
		sys_uart1_sendchar((*str++));
	}
}


void send_var(s8 var)
{
	int i,temp = 1,j = 1;
	u8 num_tmp;
	u8 var_tmp;
	
	if(var < 0){
		my_send_str("-");
		var_tmp = var * -1;
	}else{
		var_tmp = (u8)var;
	}
	
	for(i = 0; i < 10; i++)
	{
		temp = temp * 10;
		if(var_tmp < temp)	break;
		j++;
	}
	for(i = 0; i < j; i++)
	{
		temp = temp/10;
		num_tmp = var_tmp/temp;
		var_tmp = var_tmp % temp;
		sys_uart1_sendchar(num_tmp + 0x30);	
	}
}



void USARTx_TimeCheck(void)
{
	if(COM1_RX_TimeOut > 0)COM1_RX_TimeOut--;		//��ʱ����

	if(COM2_RX_TimeOut > 0)
	{
		COM2_RX_TimeOut--;		//��ʱ����
	}
}



void USART1_IRQHandler(void)
{
	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
	{ 		
		if(COM1_RX_Cnt >= COM1_RX_Lenth-1)	COM1_RX_Cnt = COM1_RX_Lenth-1;
		COM1_RX_Buffer[COM1_RX_Cnt++] = USART_ReceiveData(USART1);
		COM1_RX_TimeOut = TimeOutSet1;
		FlagMainUartOK = 1;		//�յ���������


		USART_ClearITPendingBit(USART1, USART_IT_RXNE);
	}
	
	if(USART_GetITStatus(USART1, USART_IT_TXE) != RESET)
	{     
	   USART_ClearITPendingBit(USART1, USART_IT_TXE);
	}
}




void USART2_IRQHandler(void)
{
	if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
	{

		USART_ClearITPendingBit(USART2, USART_IT_RXNE);
	}

	if(USART_GetITStatus(USART2, USART_IT_TXE) != RESET)
	{   
	   USART_ClearITPendingBit(USART2, USART_IT_TXE);	
	}
}



